@if($column)
    <span class="success-circle"></span> Active
@else
    <span class="danger-circle"></span> Inactive
@endif