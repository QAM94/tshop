<a href = "{{ asset($column->source) }}" target="_blank">
    <img src="{{ asset($column->thumbnail) }}" border="0" width="40" class="img-rounded" align="center" />
</a>